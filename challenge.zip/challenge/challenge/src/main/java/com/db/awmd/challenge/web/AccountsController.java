package com.db.awmd.challenge.web;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Account;
import com.domain.TransferRequest;
import com.exception.DuplicateAccountIdException;
import com.service.AccountsService;
import com.service.NotificationService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/accounts")
@Slf4j
public class AccountsController {
	 org.slf4j.Logger log = LoggerFactory.getLogger(AccountsController.class);
  private final AccountsService accountsService;
  private final NotificationService notifyService;
  @Autowired
  public AccountsController(AccountsService accountsService , NotificationService notifyService) 
  
  {
    this.accountsService = accountsService;
    this.notifyService=notifyService;
  }

  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Object> createAccount(@RequestBody @Valid Account account) {
	  log.info("Creating account {}", account);

    try {
    this.accountsService.createAccount(account);
    } catch (DuplicateAccountIdException daie) {
      return new ResponseEntity<>(daie.getMessage(), HttpStatus.BAD_REQUEST);
    }

    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  @GetMapping(path = "/{accountId}")
  public Account getAccount(@PathVariable String accountId) {
	  log.info("Retrieving account for id {}", accountId);
    return this.accountsService.getAccount(accountId);
  }
  @PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE,path="/transfer")
  public ResponseEntity<Object> transferAmount(@RequestBody TransferRequest request) {
	  log.info("transfer amount from accountId to accountId {}",request.getAccount1(),request.getAccount2(),request.getAmount());
	  
	  boolean status =this.accountsService.transferAmount(request.getAccount1().getAccountId(), request.getAccount2().getAccountId(), request.getAmount());
	  
	  if(status) {
		  notifyService.notifyAboutTransfer(request.getAccount1(), request.getAmount()+"has been transfered to Amount"+ request.getAccount2().getAccountId());
		  notifyService.notifyAboutTransfer(request.getAccount2(), request.getAmount()+"has been transfered to Amount"+ request.getAccount1().getAccountId());
		  
		  
		  return new ResponseEntity<>(HttpStatus.OK);
	  }
	  
	  
	return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	  	
  }
  
}
