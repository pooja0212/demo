package com.db.awmd.challenge.domain;


import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class TransferRequest {

	@NotNull
	private Account account1;

	@NotNull
	private Account account2;

	@NotNull
	private BigDecimal amount;
	
	
}
